<script src="https://rawgit.com/moment/moment/2.2.1/min/moment.min.js"></script>
<script>
    var table = $('#posted').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('admin.galery.apis')); ?>",
            method: "GET"
        },
        columns: [

            {
                data: 'post_title'
            },
            {
                data: 'is_publish'
            },
            {
                data: 'created_by'
            },
            {
                data: 'created_at'
            },
            {
                data: 'action',
                orderable: false,
                searchable: false
            }
        ]
    });

    function resetForm(modalId) {
        $(modalId).find('form')[0].reset();
    }

    $('#addDataModal').on('show.bs.modal', function(event) {
        console.log('Modal is being shown');
    });
</script>
<?php /**PATH C:\laragon\www\PISA\resources\views/admin/galery/script.blade.php ENDPATH**/ ?>