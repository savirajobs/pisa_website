

<?php $__env->startSection('title', config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 wow fadeIn" data-wow-delay="0.1s"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.05)), url(<?php echo e(asset('asset/img/hero-img.jpg')); ?>);">
        <div class="container text-center py-5">
            <h1 class="display-2 text-white mb-4">Profil</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="#">Beranda</a></li>
                    <li class="breadcrumb-item"><a href="#">Profile</a></li>
                    <li class="breadcrumb-item text-white" aria-current="page">Sekretariat</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <style>
        .container-full {
            width: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            /* Pusatkan secara horizontal */
            align-items: center;
            /* Pusatkan secara vertikal */
        }
    </style>

    <!-- About Start -->
    <div class="container-fluid py-5 about bg-light">
        <div class="container py-5">
            <div class="row g-5 align-items-center">
                <?php if(is_null($profile->notes)): ?>
                    <div class="col-lg-5 wow fadeIn" data-wow-delay="0.1s" style="height:375px;">
                        <?php if(is_null($profile->file_name)): ?>
                            <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100" alt="Image"
                                style= "height: 100%;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('/images/' . $profile->file_name)); ?>" class="img-fluid w-100" alt="Image"
                                style="height: 100%; ">
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="col-lg-5 wow fadeIn" data-wow-delay="0.1s">
                        
                        <!-- 16:9 aspect ratio -->
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" width="100%" height="375"
                                src="<?php echo e($profile->notes); ?>" allowfullscreen></iframe>
                        </div>
                        
                    </div>
                <?php endif; ?>

                


                <div class="col-lg-7 wow fadeIn" data-wow-delay="0.3s">
                    <h4
                        class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                        Tentang PISA</h4>
                    <h1 class="text-dark mb-4 display-5"><?php echo e($profile->post_title); ?></h1>
                    <p class="text-dark mb-4"><?php echo $profile->post_desc; ?>

                    </p>
                    <div class="row mb-4">
                        <div class="col-lg-6">
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2"></i>Sport Activites</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-primary"></i>Outdoor Games</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-secondary"></i>Nutritious Foods
                            </h6>
                        </div>
                        <div class="col-lg-6">
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2"></i>Highly Secured</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-primary"></i>Friendly Environment
                            </h6>
                            <h6><i class="fas fa-check-circle me-2 text-secondary"></i>Qualified Teacher</h6>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Video -->
    
    <!-- About End -->

    

    <!-- Sekretariat -->
    <div class="container-fluid program py-5">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;">
                
                <h1 class="text-dark mb-4 display-5"> <?php echo e($secretary->post_title); ?></h1>
            </div>
            <div class="row g-5 justify-content-center">
                <?php if($secretary): ?>
                    <p><?php echo $secretary->post_desc; ?></p>
                <?php else: ?>
                    <p>Deskripsi tidak tersedia.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PISA\resources\views/front/profile.blade.php ENDPATH**/ ?>