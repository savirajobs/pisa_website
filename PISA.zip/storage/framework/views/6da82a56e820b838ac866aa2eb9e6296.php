<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <?php if(Auth::user()->role == 'super-admin'): ?>
            <li class="nav-heading">Content Management</li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/post*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.post.index')); ?>">
                    <i class="bi bi-building-fill"></i>
                    <span>Pos</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.gallery.index')); ?>">
                    <i class="bi bi-card-image"></i>
                    <span>Galeri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.law.index')); ?>">
                    <i class="bi bi-journals"></i>
                    <span>Dasar Hukum</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.feedback.index')); ?>">
                    <i class="bi bi-file-earmark-arrow-down"></i>
                    <span>Konsultasi & Pengaduan</span>
                </a>
            </li>
            <li class="nav-heading">Master Management</li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.category.index')); ?>">
                    <i class="bi bi-newspaper"></i>
                    <span>Master Category</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.users.index')); ?>">
                    <i class="bi bi-person"></i>
                    <span>Master User</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/setting*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.setting.index')); ?>">
                    <i class="bi bi-gear"></i>
                    <span>Setting Page</span>
                </a>
            </li>
        <?php else: ?>
            <li class="nav-heading">Content Management</li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/post*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.post.index')); ?>">
                    <i class="bi bi-building-fill"></i>
                    <span>Pos</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.gallery.index')); ?>">
                    <i class="bi bi-card-image"></i>
                    <span>Galeri</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.law.index')); ?>">
                    <i class="bi bi-journals"></i>
                    <span>Dasar Hukum</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/user*') ? '' : 'collapsed'); ?>"
                    href="<?php echo e(route('admin.feedback.index')); ?>">
                    <i class="bi bi-file-earmark-arrow-down"></i>
                    <span>Konsultasi & Pengaduan</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>

</aside>
<?php /**PATH C:\laragon\www\PISA\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>