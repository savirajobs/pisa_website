<!-- Page Header Start -->
        <div class="container-fluid page-header py-5 wow fadeIn" data-wow-delay="0.1s"
            style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.05)), url(<?php echo e(asset('asset/img/hero-img.jpg')); ?>);">
            <div class="container text-center py-5">
                <h1 class="display-2 text-white mb-4">About Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">Pages</a></li>
                        <li class="breadcrumb-item text-white" aria-current="page">About Us</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End --><?php /**PATH C:\laragon\www\PISA\resources\views/front/pagelayouts/header.blade.php ENDPATH**/ ?>