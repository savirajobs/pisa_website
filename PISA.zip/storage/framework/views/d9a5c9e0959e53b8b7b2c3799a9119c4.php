

<?php $__env->startSection('title', config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 wow fadeIn" data-wow-delay="0.1s"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.05)), url(<?php echo e(asset('asset/img/hero-img.jpg')); ?>);">
        <div class="container text-center py-5">
            <h1 class="display-2 text-white mb-4">Program Anak</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item text-white" aria-current="page">Program Anak</li>
                    <!--<li class="breadcrumb-item text-white" aria-current="page">Our Blog</li>-->
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Programs Start -->
    <div class="container-fluid program  py-5">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Program Anak</h4>
                <h1 class="mb-5 display-3">We Offer An Exclusive Program For Kids</h1>
            </div>
            <div class="row g-5 justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-6 col-xl-4 wow fadeIn d-flex" data-wow-delay="0.1s">
                        
                        <div class="program-item rounded d-flex flex-column flex-fill">
                            <div class="program-img position-relative">
                                <a href="<?php echo e(route('frontend.program.show', ['slug' => $program->slug])); ?>">
                                    <div class="overflow-hidden img-border-radius">
                                        <?php if(is_null($program->image_name)): ?>
                                            <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100"
                                                alt="Image" style= "height: 300px;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('/images/' . $program->image_name)); ?>"
                                                class="img-fluid w-100" alt="Image" style= "height: 300px;">
                                        <?php endif; ?>
                                        
                                    </div>
                                    <div class="px-4 py-2 bg-primary text-white program-rate">Gratis</div>
                                </a>
                            </div>
                            <div class="program-text bg-white px-4 pb-3 flex-fill d-flex flex-column">
                                <div class="program-text-inner flex-grow-1 d-flex flex-column justify-content-center">
                                    <a href="<?php echo e(route('frontend.program.show', ['slug' => $program->slug])); ?>">
                                        <h4 style="text-align:center;">
                                            <?php echo e($program->post_title); ?> </h4>
                                    </a>
                                    <p class="mt-3 mb-0" style="text-align: center;">
                                        <?php echo $program->short_desc . '...'; ?></p>
                                </div>
                            </div>
                            

                        </div>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span style="text-align:center;">No Items Found</span>
                <?php endif; ?>
            </div>
            
        </div>
    </div>
    </div>

    <!-- Program End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PISA\resources\views/front/program.blade.php ENDPATH**/ ?>