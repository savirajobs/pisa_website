

<?php $__env->startSection('title', config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 wow fadeIn" data-wow-delay="0.1s"
        style="background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.05)), url(<?php echo e(asset('asset/img/hero-img.jpg')); ?>);">
        <div class="container text-center py-5">
            <h1 class="display-2 text-white mb-4">Program Anak</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Program Anak</a></li>
                    <li class="breadcrumb-item text-white" aria-current="page"><?php echo e($program->post_title); ?></li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->
    
    <style>
        .carousel-item img {
            width: 100%;
            /* Membuat gambar memenuhi lebar kontainer */
            height: 750px;
            /* Menjaga proporsi tinggi */
            object-fit: cover;
            /* Memotong gambar jika perlu */
            padding: 10px;
            transition: all 0.5s ease-in-out;
            z-index: 10;
            opacity: 1;
        }

        .container-full {
            width: 100%;
            margin: 0;
            padding: 0;
        }
    </style>

    <!-- Start Section -->
    <div class="container-fluid program  py-5">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Program Anak</h4>
                <h1 class="mb-5 display-4"><?php echo e($program->post_title); ?></h1>
            </div>
            <div class="row g-5 justify-content-center">
                <div class="program-img position-relative">
                    <p style="text-align:center;">by <?php echo e($user); ?> -
                        <?php echo e(\Carbon\Carbon::parse($program->created_at)->translatedFormat('l, d F Y')); ?></p>
                    <div class="top-link d-flex gap-3 pe-2" style="justify-content: center; align-items: center; margin-bottom:10px;">
                        <!-- Share to Facebook -->
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>"
                            class="btn btn-secondary btn-sm-square rounded-circle"><i
                                class="fab fa-facebook-f text-white fa-lg"></i></a>
                        <!-- Share to Twitter -->
                        <a href="https://twitter.com/intent/tweet?text=<?php echo e(urlencode($program->post_title)); ?>&url=<?php echo e(urlencode(request()->fullUrl())); ?>"
                            class="btn btn-secondary btn-sm-square rounded-circle"><i
                                class="fab fa-twitter text-white fa-lg"></i></a>
                        <!-- Share to Whatsapp -->
                        <a href="https://wa.me/?text=<?php echo e(urlencode($program->post_title . ' ' . request()->fullUrl())); ?>"
                            class ="btn btn-secondary btn-sm-square rounded-circle"><i
                                class="fab fa-whatsapp text-white fa-lg"></i></a>
                        <!-- Share to LinkedIn -->
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(request()->fullUrl())); ?>"
                            class="btn btn-secondary btn-sm-square rounded-circle me-0"><i
                                class="fab fa-linkedin-in text-white fa-lg"></i></a>
                    </div>
                    <div id="carouselExample" class="carousel slide">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $filenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $filename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                    <img src="<?php echo e(asset('/images/' . $filename)); ?>" class="d-block w-100"
                                        alt="Slide <?php echo e($index + 1); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>


                    
                </div>
                <div class="container-full py-5 justify">
                    <p style="text-align: justify; font-size: 100%;">
                        <?php echo $program->post_desc; ?>

                    </p>
                </div>
                <div class="container-full"
                    style="display: flex; flex-direction: column; justify-content: center; align-items: center;">
                    <h6 style="text-align:center;">Untuk mengetahui infromasi pendaftaran bisa menghubungi kontak berikut
                        ini :</h6>
                    <i class="bi bi-calendar2-check" style="font-size: 48px; margin-top: 10px;"></i>
                    <h6 style="text-align:center;"><?php echo e($program->post_title); ?></h6>
                    <?php if(is_null($program->notes)): ?>
                        <button type="button" class="btn btn-primary">Daftar</button>
                    <?php else: ?>
                        <h6 style="text-align:center; margin-top:10px;"> <?php echo e($program->notes); ?></h6>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>
    </div>

    <!-- End section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PISA\resources\views/front/program-detail.blade.php ENDPATH**/ ?>