<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
	<meta name="robots" content="noindex" />
	<meta name="googlebot" content="noindex" />
	<meta name="googlebot-news" content="noindex" />
	<meta name="slurp" content="noindex" />
	<meta name="msnbot" content="noindex" />
	<meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
	<link href="<?php echo e(asset('asset/img/favicon.png')); ?>" rel="icon">
	<link href="<?php echo e(asset('asset/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
	<link href="https://fonts.gstatic.com" rel="preconnect">
	<link
		href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
		rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css"
		integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg=="
		crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link rel="stylesheet"
		href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.1/font/bootstrap-icons.min.css"
		integrity="sha512-oAvZuuYVzkcTc2dH5z1ZJup5OmSQ000qlfRvuoTTiyTBjwX1faoyearj8KdMq0LgsBTHMrRuMek7s+CxF8yE+w=="
		crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link href="<?php echo e(asset('asset/css/style.css')); ?>" rel="stylesheet">
	<style>
		.invalid-feedback {
			display: block !important;
		}
	</style>
	<?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>

	<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js"
		integrity="sha512-7Pi/otdlbbCR+LnW+F7PwFcSDJOuUJB3OxtEHbg4vSMvzvJjde4Po1v4BR9Gdc9aXNUNFVUY+SK51wWT8WF0Gg=="
		crossorigin="anonymous" referrerpolicy="no-referrer"></script>

	<script src="<?php echo e(asset('asset/js/main.js')); ?>"></script>
	<?php echo $__env->yieldPushContent('js'); ?>
</body>

</html><?php /**PATH C:\laragon\www\PISA\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>