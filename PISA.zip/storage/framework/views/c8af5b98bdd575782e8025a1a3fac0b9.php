<?php $__env->startSection('title', config('app.name')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Start -->
    <div id="heroCarousel" class="carousel slide position-relative" data-bs-ride="carousel" data-bs-interval="2500">

        <!-- Teks tetap floating di atas carousel -->

        <div class="position-absolute top-50 translate-middle text-start"
            style="z-index: 10; max-width: 100%; left: 30%; margin-left: 20px;">
            <h1 class="mb-3 text-primary">Kota Blitar</h1>
            <h1 class="mb-5 display-1 text-white">Pusat Informasi <br> Sahabat Anak</h1>
        </div>


        <div class="carousel-inner">
            <?php if($header_img->isNotEmpty()): ?>
                <?php $__currentLoopData = $header_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $headerimg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                        <div class="carousel-image"
                            style="background: linear-gradient(rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.3)), url('<?php echo e(asset('images/' . $headerimg->file_name)); ?>'); background-repeat: no-repeat; background-position: center center; background-size: cover; height: 50vh;">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                    <div class="carousel-image"
                        style="background: linear-gradient(rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.3)), url('<?php echo e(asset('/asset/img/no-image.jpg')); ?>'); background-repeat: no-repeat; background-position: center center; background-size: cover; height: 50vh;">
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- Hero End -->

    

    <!-- About Start -->
    <div class="container-fluid py-5 about bg-light"
        style="background: linear-gradient(rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.8)), url(<?php echo e(asset('asset/img/background.jpg')); ?>);">
        <div class="container py-5">
            <div class="row g-5 align-items-center">
                <?php if(is_null($profile->notes)): ?>
                    <div class="col-lg-5 wow fadeIn" data-wow-delay="0.1s">
                        <?php if(is_null($profile->file_name)): ?>
                            <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100" alt="Image"
                                style= "height: 100%;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('/images/' . $profile->file_name)); ?>" class="img-fluid w-100" alt="Image"
                                style="height: 100%; ">
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="col-lg-5 wow fadeIn" data-wow-delay="0.1s">
                        <iframe width="100%" height="400" src="<?php echo e($profile->notes); ?>"allowfullscreen>
                        </iframe>
                    </div>
                <?php endif; ?>
                <div class="col-lg-7 wow fadeIn" data-wow-delay="0.3s">
                    <h4
                        class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                        Tentang PISA</h4>
                    <h1 class="text-dark mb-4 display-5"><?php echo e($profile->post_title); ?></h1>
                    <p class="text-dark mb-4"><?php echo $profile->post_desc; ?>

                    </p>
                    <div class="row mb-4">
                        <div class="col-lg-6">
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2"></i>Perpustakaan</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-primary"></i>Ruang Baca</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-secondary"></i>Ruang Kreatifitas</h6>
                        </div>
                        <div class="col-lg-6">
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2"></i>Ruang Multimedia</h6>
                            <h6 class="mb-3"><i class="fas fa-check-circle me-2 text-primary"></i>Permainan Edukasi</h6>
                            <h6><i class="fas fa-check-circle me-2 text-secondary"></i>Permainan Tradisional</h6>
                        </div>
                    </div>
                    <a href="" class="btn btn-primary px-5 py-3 btn-border-radius">More Details</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Video -->
    
    <!-- About End -->

    

    <!-- Programs Start -->
    <div class="container-fluid program py-5 bg-white">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Program Anak</h4>
                <h1 class="mb-5 display-3">Program For Kids</h1>
            </div>
            <div class="row g-5 justify-content-center">
                <?php if($latest_programs->isNotEmpty()): ?>
                    <?php $__currentLoopData = $latest_programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeIn d-flex" data-wow-delay="0.1s">
                            
                            <div class="program-item rounded d-flex flex-column flex-fill">
                                <div class="program-img position-relative">
                                    <a href="<?php echo e(route('frontend.program.show', ['slug' => $program->slug])); ?>">
                                        <div class="overflow-hidden img-border-radius">
                                            <?php if(is_null($program->image_name)): ?>
                                                <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100"
                                                    alt="Image" style= "height: 300px;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('/images/' . $program->image_name)); ?>"
                                                    class="img-fluid w-100" alt="Image" style= "height: 300px;">
                                            <?php endif; ?>
                                            
                                        </div>
                                        <div class="px-4 py-2 bg-primary text-white program-rate">Gratis</div>
                                    </a>
                                </div>
                                <div class="program-text bg-white px-4 pb-3 flex-fill d-flex flex-column">
                                    <a href="<?php echo e(route('frontend.program.show', ['slug' => $program->slug])); ?>">
                                        <div class="program-text-inner flex-grow-1 d-flex flex-column justify-content-center"
                                            style="height: 100%; min-height: 150px; max-height: 300px; overflow-y: auto;">
                                            <a href="<?php echo e(route('frontend.program.show', ['slug' => $program->slug])); ?>"
                                                class="h4" style="text-align:center;">
                                                <?php echo e($program->post_title); ?> </a>
                                            <p class="mt-3 mb-0">
                                                <?php echo $program->short_desc . '...'; ?></p>
                                        </div>
                                    </a>
                                </div>
                                
                            </div>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <!-- Kode jika $items kosong -->
                    <span style="text-align:center;">Program tidak ditemukan</span>
                <?php endif; ?>
            </div>
            <div class="text-center wow fadeIn" data-wow-delay="0.1s" style= "margin-top: 50px;";>
                <a href="<?php echo e(route('frontend.program.index')); ?>"
                    class="btn btn-primary px-5 py-3 text-white btn-border-radius">Vew All Programs</a>
            </div>
        </div>
    </div>
    </div>

    <!-- Program End -->
    
    <!-- Events Start -->
    <div class="container-fluid events py-5 bg-white">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Informasi</h4>
                <h1 class="mb-5 display-3">Our Events</h1>
            </div>

            <div class="row g-5 justify-content-center">
                <?php if($latest_events->isNotEmpty()): ?>
                    <?php $__currentLoopData = $latest_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeIn d-flex" data-wow-delay="0.1s">
                            <div class="events-item bg-primary rounded d-flex flex-column flex-fill">
                                <div class="events-inner position-relative">
                                    <div class="events-img overflow-hidden rounded-circle position-relative"
                                        style="height:255px;">
                                        <?php if(is_null($event->image_name)): ?>
                                            <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>"
                                                class="img-fluid w-100 rounded-circle" alt="Image">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('/images/' . $event->image_name)); ?>"
                                                class="img-fluid w-100 rounded-circle" alt="Image"
                                                style="height:255px;">
                                        <?php endif; ?>
                                        
                                        <div class="event-overlay">
                                            <?php if(is_null($event->image_name)): ?>
                                                <a href="<?php echo e(asset('/asset/img/no-image.jpg')); ?>"
                                                    data-lightbox="event-1"><i
                                                        class="fas fa-search-plus text-white fa-2x"></i></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(asset('/images/' . $event->image_name)); ?>"
                                                    data-lightbox="event-1"><i
                                                        class="fas fa-search-plus text-white fa-2x"></i></a>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                    <div class="px-4 py-2 bg-secondary text-white text-center events-rate">
                                        Informasi
                                    </div>
                                    <div class="d-flex justify-content-between px-4 py-2 bg-secondary">
                                        <small class="text-white"><i class="fas fa-calendar me-1 text-primary"></i>
                                            <?php echo e(\Carbon\Carbon::parse($event->created_at)->format('d M Y')); ?></small>
                                        <small class="text-white"><i class="fas fa-map-marker-alt me-1 text-primary"></i>
                                            <?php if(is_null($event->notes)): ?>
                                                Kota Blitar
                                            <?php else: ?>
                                                <?php echo e($event->notes); ?>

                                            <?php endif; ?>
                                        </small>
                                    </div>
                                </div>
                                <div class="events-text p-4 border border-primary bg-white border-top-0 rounded-bottom flex-fill d-flex flex-column"
                                    style="height:50%; min-height:150px; max-height:300px; overflow-y: auto;">
                                    <a href="#" class="h4"> <?php echo e($event->post_title); ?></a>
                                    <p class="mb-0 mt-3"> <?php echo $event->short_desc . '...'; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <!-- Kode jika $items kosong -->
                    <span style="text-align:center;">Informasi tidak ditemukan</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-center wow fadeIn" data-wow-delay="0.1s">
            <a href="#" class="btn btn-primary px-5 py-3 text-white btn-border-radius">Vew All Events</a>
        </div>
    </div>
    <!-- Events End-->
    
    <!-- Blog Start-->
    <div class="container-fluid blog py-5">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 600px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Berita</h4>
                <h1 class="mb-5 display-3">Latest News & Blog</h1>
            </div>
            <div class="row g-5 justify-content-center">
                <?php if($latest_news->isNotEmpty()): ?>
                    <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-6 col-xl-4 wow fadeIn d-flex" data-wow-delay="0.1s">
                            <div class="blog-item rounded-bottom d-flex flex-column flex-fill">
                                <div class="blog-img overflow-hidden position-relative img-border-radius">
                                    <?php if(is_null($news->image_name)): ?>
                                        <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100"
                                            alt="Image" style="height: 300px;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/images/' . $news->image_name)); ?>" class="img-fluid w-100"
                                            alt="Image" style="height: 300px;">
                                    <?php endif; ?>
                                </div>
                                <div
                                    class="d-flex justify-content-between px-4 py-3 bg-light border-bottom border-primary blog-date-comments">
                                    <small class="text-dark"><i class="fas fa-calendar me-1 text-dark"></i>
                                        <?php echo e(\Carbon\Carbon::parse($news->created_at)->format('d M Y')); ?></small>
                                    
                                </div>
                                <div class="px-4 pb-4 bg-light rounded-bottom flex-fill d-flex flex-column">
                                    <div class="blog-text-inner flex-grow-1" style="margin-top:10px;">
                                        <a href="#" class="h4"><?php echo e($news->post_title); ?></a>
                                        <p class="mt-3 mb-4"><?php echo $news->short_desc . '...'; ?></p>
                                    </div>
                                    <div class="text-center mt-auto">
                                        <a href="#"
                                            class="btn btn-primary text-white px-4 py-2 mb-3 btn-border-radius">View
                                            Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <!-- Kode jika $items kosong -->
                    <span style="text-align:center;">Berita tidak ditemukan</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Blog End-->
    
    <!-- Team Start-->
    <div class="container-fluid team py-5">
        <div class="container py-5">
            <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 600px;">
                <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                    Galeri Foto</h4>
                <h1 class="mb-5 display-3">Dokumentasi Kegiatan</h1>
            </div>
            <div class="row g-5 justify-content-center">
                <?php if($gallery_img->isNotEmpty()): ?>
                    <?php $__currentLoopData = $gallery_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.1s">
                            <a href="<?php echo e(route('frontend.images.show', ['slug' => $gallery->slug])); ?>">
                                <div
                                    class="team-item border border-primary img-border-radius overflow-hidden d-flex flex-column">
                                    <?php if(is_null($gallery->image_name)): ?>
                                        <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100"
                                            alt="Image" style="height:286px;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/images/' . $gallery->image_name)); ?>" class="img-fluid w-100"
                                            alt="Image" style="height:286px;">
                                    <?php endif; ?>
                                    
                                    <div class="team-content text-center py-3  flex-grow-1">
                                        <h4 class="text-primary"><?php echo e($gallery->post_title); ?></h4>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <!-- Kode jika $items kosong -->
                    <span style="text-align:center;">Galeri tidak ditemukan</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Team End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PISA\resources\views/front/index.blade.php ENDPATH**/ ?>