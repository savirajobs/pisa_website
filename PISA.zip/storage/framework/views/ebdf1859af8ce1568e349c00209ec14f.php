

<?php $__env->startSection('title',config('app.name')); ?>

<?php $__env->startSection('content'); ?>

<!-- Programs Start -->
<div class="container-fluid program  py-5">
    <div class="container py-5">    
        <div class="mx-auto text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px;" >
            <h4 class="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
                Program Anak</h4>
            <h1 class="mb-5 display-3">We Offer An Exclusive Program For Kids</h1>
        </div>
        <div class="row g-5 justify-content-center">
            <?php $__currentLoopData = $latest_programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-6 col-xl-4 wow fadeIn" data-wow-delay="0.1s" >
                
                <div class="program-item rounded">
                    <div class="program-img position-relative">
                        <div class="overflow-hidden img-border-radius">
                        <?php if(is_null($program->image_name)): ?>
                            <img src="<?php echo e(asset('/asset/img/no-image.jpg')); ?>" class="img-fluid w-100" alt="Image" style= "height: 300px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('/asset/img/' . $program->image_name)); ?>" class="img-fluid w-100" alt="Image" style= "height: 300px;">
                        <?php endif; ?>
                        
                        </div>                        
                        <div class="px-4 py-2 bg-primary text-white program-rate">Gratis</div>
                    </div>
                    <div class="program-text bg-white px-4 pb-3">
                        <div class="program-text-inner" style= "height: 100px;">
                            <a href="#" class="h4">
                            <?php echo e($program->post_title); ?> </a>
                            <p class="mt-3 mb-0">
                            <?php echo e($program->short_desc); ?></p>
                        </div>
                    </div>
                    <div class="program-teacher d-flex align-items-center border-top border-primary bg-white px-4 py-3">
                        <img src="<?php echo e(asset('asset/img/program-teacher.jpg')); ?>"
                            class="img-fluid rounded-circle p-2 border border-primary bg-white" alt="Image"
                            style="width: 70px; height: 70px;">
                        <div class="ms-3">
                            <h6 class="mb-0 text-primary"><?php echo e($program->user_name); ?></h6>
                            <small>Tim Penulis</small>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between px-4 py-2 bg-primary rounded-bottom">
                        <small class="text-white"><i class="fas fa-wheelchair me-1"></i> 30 Sits</small>
                        <small class="text-white"><i class="fas fa-book me-1"></i> 11 Lessons</small>
                        <small class="text-white"><i class="fas fa-clock me-1"></i> 60 Hours</small>
                    </div>
                </div>
                
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center wow fadeIn" data-wow-delay="0.1s" style= "margin-top: 50px;";>
                <a href="#" class="btn btn-primary px-5 py-3 text-white btn-border-radius">Vew All Programs</a>
            </div>
        </div>
    </div>
</div>

<!-- Program End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.pagelayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PISA\resources\views/front/programlist.blade.php ENDPATH**/ ?>